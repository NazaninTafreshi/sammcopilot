# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [2.0.0] - 2023-11-20
### Added

### Changed
* From static to dynamic data attributes.
* Converted from BAMM to SAMM.

### Removed

## [1.0.0] - 2023-02-22
### Added
- initial model

### Changed
n/a

### Removed

