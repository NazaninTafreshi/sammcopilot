# Changelog

All notable changes to this model will be documented in this file.

## [1.0.0] 2024-07-29

- initial version of the aspect model for CustomsInformation
