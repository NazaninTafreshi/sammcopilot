# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [1.0.0] - 2024-03-11
### Added
- initial version of this model

### Changed
n/a

### Removed

