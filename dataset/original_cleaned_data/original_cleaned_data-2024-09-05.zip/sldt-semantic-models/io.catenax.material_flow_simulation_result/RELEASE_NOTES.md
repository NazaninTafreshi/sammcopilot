# Changelog

All notable changes to this model will be documented in this file.

## [3.0.0] 2024-05-21

- Add BPNS as entity with properties
- Update header
- Replace `batchID` with `batchSerialNumber`

## [2.0.0] 2023-10-16

### Added

- Entity containing the properties of a Material Flow Simulation Result

## [1.0.0]

- initial version of the aspect model for Material Flow Simulation Result
