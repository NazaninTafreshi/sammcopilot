# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [1.0.1] - 2022-08-26
### Added
- initial model
- small fixes 

### Changed
n/a

### Removed

