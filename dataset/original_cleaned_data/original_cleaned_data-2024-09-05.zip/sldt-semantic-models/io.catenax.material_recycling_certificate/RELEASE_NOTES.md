# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [1.0.0] - 2023-12-04
### Added
- initial model

### Changed

### Removed
