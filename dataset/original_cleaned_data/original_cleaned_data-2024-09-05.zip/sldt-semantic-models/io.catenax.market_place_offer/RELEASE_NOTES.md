# Changelog
All notable changes to this model will be documented in this file.

## [2.0.0] - 2024-02-05
### Added
- new aspect based on shared aspect "recycling strategy certificate"
- other new aspects
- link several more models

### Changed
- Upgrade from BAMM model to SAMM model
- some aspects

### Removed
- 2 aspects

## [1.4.0] - 2023-01-30
### Added
n/a

### Changed
- attachment changed to set already
- quantity description changed

### Removed
- status
- certificate

## [1.3.0] - 2022-10-28
### Added
- initial model
- incremental additions of properties

### Changed
n/a

### Removed
n/a