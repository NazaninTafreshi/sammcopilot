# Changelog
All notable changes to this model will be documented in this file.

## [1.0.0] - 2023-11-07

### Added
- initial version of the aspect model for material demand