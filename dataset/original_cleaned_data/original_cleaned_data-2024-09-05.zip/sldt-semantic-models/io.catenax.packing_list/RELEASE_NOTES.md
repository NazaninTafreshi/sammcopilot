# Changelog
All notable changes to this model will be documented in this file.

## [1.0.0] - 2024-02-05
### Added
- initial model

### Changed
n/a

### Removed

