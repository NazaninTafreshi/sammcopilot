# Changelog
All notable changes to this model will be documented in this file.

## [1.0.0] - 2023-10-23

### Added
- initial version of this model