# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [1.1.0] - 2022-04-01
### Added
- initial model
- some additions of properties

### Changed
n/a

### Removed

