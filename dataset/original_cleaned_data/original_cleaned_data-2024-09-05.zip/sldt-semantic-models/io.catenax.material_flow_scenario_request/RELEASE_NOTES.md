# Changelog

All notable changes to this model will be documented in this file.

## [2.0.0] 2024-05-21

- Instead of one scenario parameter we can now define a set of scenario parameters
- Change scenario owner characteristic to BusinessPartnerSite

## [1.0.0] 2023-10-23

- initial version of the aspect model for Scenario Simulation Request
