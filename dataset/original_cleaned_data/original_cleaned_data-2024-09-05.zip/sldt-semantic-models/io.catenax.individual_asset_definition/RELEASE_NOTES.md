# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [2.0.0] - 2024-02-02

### Added

### Changed
- converted from Bamm to Samm

### Removed

## [1.0.0] - 2023-02-22

### Added
- initial model
- 2023-03-17 added physicalDimensions (Shared Aspect)
### Changed
n/a

### Removed

