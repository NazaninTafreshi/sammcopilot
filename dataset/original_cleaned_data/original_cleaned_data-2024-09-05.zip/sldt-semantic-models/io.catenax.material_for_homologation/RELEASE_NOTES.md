# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [2.0.0] - 2024-02-15
This model is in status draft, as this is just the conversion of existing model from bamm to samm and not released model.
This version can still be considered for updates.

## [1.0.0] - 2022-06-22
### Added
- initial model

### Changed
n/a

### Removed

