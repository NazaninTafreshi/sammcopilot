# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [1.1.1] - 2022-08-26
### Added
- initial model
- some additions
- fix in example value

### Changed
n/a

### Removed

