# Changelog
All notable changes to this model will be documented in this file.

## [Unreleased]

## [1.0.1] - 2022-09-15
### Added
- initial model
- fix in example value

### Changed
n/a

### Removed

